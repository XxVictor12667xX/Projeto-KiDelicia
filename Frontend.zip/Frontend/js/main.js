// js/main.js
// Roteador mínimo da SPA e integração entre módulos

import { renderMenu } from './ui/menuUI.js';
import { renderCartPanel } from './ui/cartUI.js';
import { refreshCartIndicator } from './ui/uiHelpers.js';
import { closeModal } from './ui/modalUI.js';
import { renderOrders } from './order.js';
import { getCount } from './cart.js';

// inicialização
const routes = {
  menu: async () => { await renderMenu(); attachCart(); },
  pedidos: async () => {
    const app = document.getElementById('app');
    app.innerHTML = '<h2>Pedidos</h2><div id="orders-placeholder">Carregando...</div>';
    const ph = document.getElementById('orders-placeholder');
    await renderOrders(ph);
    attachCart();
  },
  admin: async () => {
    window.location.href = 'admin.html';
  }
};

function attachCart() {
  // cria painel do carrinho
  const existing = document.getElementById('cart-panel');
  renderCartPanel(existing);
  refreshCartIndicator();
}

// nav buttons
document.querySelectorAll('.nav-btn').forEach(btn => {
  btn.addEventListener('click', async (e) => {
    document.querySelectorAll('.nav-btn').forEach(b=>b.classList.remove('active'));
    e.target.classList.add('active');
    const route = e.target.dataset.route;
    await routes[route]();
  });
});

// modal close ao clicar fora
document.getElementById('modal').addEventListener('click', (ev) => {
  if (ev.target === ev.currentTarget) closeModal();
});

// inicia em menu
routes.menu();
