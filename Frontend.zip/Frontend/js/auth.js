// js/auth.js
// Autenticação admin mínima (usa api.loginRequest); mantém token em localStorage

import { loginRequest } from './api.js';
const TOKEN_KEY = 'kidelicia_token';

export async function login(email, password) {
  const resp = await loginRequest(email, password);
  if (resp && resp.token) {
    localStorage.setItem(TOKEN_KEY, resp.token);
    return resp;
  }
  throw new Error('Falha ao autenticar');
}

export function getToken() {
  return localStorage.getItem(TOKEN_KEY);
}
export function logout() {
  localStorage.removeItem(TOKEN_KEY);
}
