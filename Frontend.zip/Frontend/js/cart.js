// js/cart.js
// Gerencia o estado do carrinho no frontend.
// exporta API simples para adicionar/remover items e persistência local (localStorage).

const STORAGE_KEY = 'kidelicia_cart_v1';

let cart = {
  items: [] // cada item: { id, name, price, qty }
};

// carrega do localStorage
function load() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) cart = JSON.parse(raw);
  } catch (e) { cart = {items:[]} }
}
function save() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
}
load();

// adiciona item (ou incrementa qtd)
export function addToCart(product, qty = 1) {
  const found = cart.items.find(i => i.id === product.id);
  if (found) {
    found.qty += qty;
  } else {
    cart.items.push({ id: product.id, name: product.name, price: Number(product.price), qty });
  }
  save();
  return cart;
}

// remove item completamente
export function removeFromCart(id) {
  cart.items = cart.items.filter(i => i.id !== id);
  save();
  return cart;
}

// atualiza quantidade
export function updateQty(id, qty) {
  const it = cart.items.find(i => i.id === id);
  if (!it) return cart;
  it.qty = Math.max(0, Number(qty));
  if (it.qty === 0) cart.items = cart.items.filter(i => i.id !== id);
  save();
  return cart;
}

export function clearCart() {
  cart.items = [];
  save();
  return cart;
}

export function getCart() {
  return JSON.parse(JSON.stringify(cart));
}

export function getTotal() {
  return cart.items.reduce((s,i)=> s + i.price * i.qty, 0);
}

export function getCount() {
  return cart.items.reduce((s,i)=> s + i.qty, 0);
}
