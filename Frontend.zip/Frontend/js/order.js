// js/order.js
// Funções utilitárias para exibir lista de pedidos (admin) e atualizar status.
// Usa fetchOrders() do api.js.

import { fetchOrders } from './api.js';

// renderiza pedidos (admin)
export async function renderOrders(container) {
  const orders = await fetchOrders();
  if (!orders || orders.length === 0) {
    container.innerHTML = '<p class="small">Nenhum pedido encontrado</p>';
    return;
  }
  container.innerHTML = orders.map(o => `
    <div class="card">
      <div style="display:flex;justify-content:space-between">
        <div><strong>Pedido ${o.id || o.orderId}</strong><div class="small">${o.customer || 'Cliente'} • ${o.table || ''}</div></div>
        <div class="small">R$ ${Number(o.total || 0).toFixed(2)}</div>
      </div>
      <div class="small">Status: ${o.status || 'Recebido'}</div>
      <div style="margin-top:8px">${(o.items||[]).map(i=>`<div class="small">${i.qty}x ${i.name}</div>`).join('')}</div>
      <div style="margin-top:8px">
        <button class="btn ghost btn-status" data-id="${o.id}" data-status="Em preparo">Em preparo</button>
        <button class="btn ghost btn-status" data-id="${o.id}" data-status="Pronto">Pronto</button>
        <button class="btn ghost btn-status" data-id="${o.id}" data-status="Entregue">Entregue</button>
      </div>
    </div>
  `).join('');
  // eventos de atualização de status podem chamar a API para persistir (não implementado aqui)
}
