// checkoutUI.js
// Formulário de finalização e envio do pedido.

import { createOrder } from '../api.js';
import { getCart, getTotal, clearCart } from '../cart.js';
import { refreshCartIndicator } from './uiHelpers.js';

export function renderCheckoutForm(panel) {
  panel.innerHTML = `
    <h3>Finalizar Pedido</h3>
    <form id="checkout-form">
      <label>Nome: <input name="customer" required /></label>
      <label>Mesa / Referência: <input name="table" /></label>
      <label>Observações: <textarea name="notes"></textarea></label>
      <p><strong>Total: R$ ${getTotal().toFixed(2)}</strong></p>
      <button type="submit" class="btn primary">Confirmar Pedido</button>
      <button type="button" id="btn-back" class="btn ghost">Voltar</button>
    </form>
  `;

  document.getElementById('btn-back').addEventListener('click', () => window.location.reload());

  document.getElementById('checkout-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const form = e.target;
    const payload = {
      customer: form.customer.value,
      table: form.table.value,
      notes: form.notes.value,
      items: getCart().items,
      total: getTotal()
    };
    const resp = await createOrder(payload);
    panel.innerHTML = `<h3>Pedido Enviado!</h3>
      <p>Número do pedido: <strong>${resp.orderId || 'SIM-'+Date.now()}</strong></p>
      <p>Obrigado, ${payload.customer}!</p>`;
    clearCart();
    refreshCartIndicator();
  });
}
