// modalUI.js
// Responsável apenas por abrir e fechar o modal de detalhes do item.

import { addToCart } from '../cart.js';
import { refreshCartIndicator } from './uiHelpers.js';

const modal = document.getElementById('modal');
const modalContent = document.getElementById('modal-content');

export function showDetails(item) {
  modalContent.innerHTML = `
    <button id="close-modal" class="btn ghost" style="float:right">Fechar</button>
    <img src="${item.image}" alt="${item.name}" />
    <h3>${item.name}</h3>
    <p>${item.desc}</p>
    <p class="small">Preço: R$ ${Number(item.price).toFixed(2)}</p>
    <div style="margin-top:10px">
      <label>Quantidade: <input id="modal-qty" type="number" value="1" min="1" style="width:60px" /></label>
      <button id="modal-add" class="btn primary">Adicionar ao pedido</button>
    </div>
  `;
  modal.classList.remove('hidden');
  modal.setAttribute('aria-hidden', 'false');

  document.getElementById('close-modal').addEventListener('click', closeModal);
  document.getElementById('modal-add').addEventListener('click', () => {
    const qty = Number(document.getElementById('modal-qty').value) || 1;
    addToCart(item, qty);
    refreshCartIndicator();
    closeModal();
  });
}

export function closeModal() {
  modal.classList.add('hidden');
  modal.setAttribute('aria-hidden', 'true');
  modalContent.innerHTML = '';
}
