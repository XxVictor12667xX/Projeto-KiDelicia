// uiHelpers.js
// Funções pequenas e reutilizáveis de interface.

import { getCount } from '../cart.js';

export function refreshCartIndicator() {
  document.getElementById('cart-count').textContent = getCount();
}
