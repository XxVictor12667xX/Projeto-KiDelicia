// js/api.js
// Wrapper para chamadas ao backend RESTful.
// Se o backend não estiver disponível, usamos o arquivo local data/sample-menu.json como fallback.

const API_BASE = '/api'; // ajuste para o seu backend (ex: http://localhost:3000)

// --- helpers de request
async function safeFetch(url, options = {}) {
  try {
    const res = await fetch(url, options);
    if (!res.ok) throw new Error('HTTP ' + res.status);
    return await res.json();
  } catch (err) {
    throw err;
  }
}

// --- menu
export async function fetchMenu() {
  // tenta o backend primeiro
  try {
    return await safeFetch(`${API_BASE}/menu`);
  } catch (err) {
    // fallback local (arquivo de exemplo)
    return await safeFetch('/data/sample-menu.json');
  }
}

// --- pedidos
export async function createOrder(orderPayload) {
  // envia pedido ao backend via POST
  try {
    return await safeFetch(`${API_BASE}/orders`, {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify(orderPayload)
    });
  } catch (err) {
    // simula resposta se backend não existir
    return { success: true, orderId: 'SIM-'+Date.now() };
  }
}

export async function fetchOrders() {
  try {
    return await safeFetch(`${API_BASE}/orders`);
  } catch (err) {
    return []; // fallback
  }
}

// --- admin login (token-based)
export async function loginRequest(email, password) {
  try {
    return await safeFetch(`${API_BASE}/auth/login`, {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({email, password})
    });
  } catch (err) {
    // fallback simulado
    if (email === 'admin@kidelicia.local' && password === 'kide123') {
      return { token: 'SIMULADO_TOKEN_ADMIN', user: {name: 'Admin'} };
    }
    throw new Error('Credenciais inválidas (fallback)');
  }
}

// exporta funções para CRUD de itens (admin)
export async function createMenuItem(payload, token) {
  return await safeFetch(`${API_BASE}/menu`, {
    method: 'POST',
    headers: {'Content-Type':'application/json','Authorization': 'Bearer ' + token},
    body: JSON.stringify(payload)
  });
}
export async function updateMenuItem(id, payload, token) {
  return await safeFetch(`${API_BASE}/menu/${id}`, {
    method: 'PUT',
    headers: {'Content-Type':'application/json','Authorization': 'Bearer ' + token},
    body: JSON.stringify(payload)
  });
}
export async function deleteMenuItem(id, token) {
  return await safeFetch(`${API_BASE}/menu/${id}`, {
    method: 'DELETE',
    headers: {'Authorization': 'Bearer ' + token}
  });
}
